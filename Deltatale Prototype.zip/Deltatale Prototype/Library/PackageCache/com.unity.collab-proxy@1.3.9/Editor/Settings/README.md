# Unity Collaborate Settings
This directory contains implementations and bindings for the Unity Settings package. All settings for the package are managed in this directory.
